#!/bin/bash

echo "🚀 Starting Olivia's Discord Integration on Railway"
echo "===================================================="

# Start unified server (handles both MCP and Actions)
exec python unified_server.py
