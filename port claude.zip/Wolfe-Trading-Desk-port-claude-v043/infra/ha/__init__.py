# path: infra/ha/__init__.py
from .leader import LeaderElector
